# Experiment 44: dynamic versus static full-model S256 comparison

Extract both Python files into `/content/drive/MyDrive/moe_iree_olmoe/`, then run on the A100:

```python
!python /content/drive/MyDrive/moe_iree_olmoe/44_dynamic_full_model_comparison.py --setup
```

No notebook variables are needed. The pinned experiment-42 companion is included.
Uses the existing original and tuned VMFBs, archived weights, four S256 inputs,
HF references, and validated A100 dynamic expert binary. It may fetch only the
pinned config.json if absent; no checkpoint weight download is performed.

## What changes

New IREE entry points execute embedding, each attention/router/packing block,
combination and final projection. The existing dynamic expert binary handles
only each expert's actual routed rows. All model computation uses IREE.
There are 16 host count readbacks and a Python extract/expert/insert loop per
layer. Weights are uploaded once outside timing. Packing and output assembly
retain fixed padded buffers; this is not a fully compact or fully in-graph
ragged implementation. Functional insertion may incur buffer-copy costs.

The exact static full-model binaries from experiment 42 are reused.
The dynamic arm is a new full-model integration of the old expert kernel,
not a historical full-model prototype and not the fastest possible dynamic
implementation. Graph partitioning, fusion boundaries, host calls, GEMM rank,
and arithmetic workload differ. Ratios compare implementations; they do not
isolate the causal cost of dynamic shapes or runtime decisions alone.

## Protocol and gates

- A100 sm_80; FP32, TF32 disabled; batch one, S256, no KV cache.
- Original / dynamic / tuned / tuned / dynamic / original: isolated processes.
- Four frozen prompt fixtures, 20 samples each: 480 timed requests total.
- Same boundary: resident token IDs to completed host serving logits/counts.
- Compilation, archive loading, initial weight upload and diagnostics excluded.
- At least ten warmup calls/five seconds, two five-call windows within 2%; bounded
  at 60 calls/45 seconds. An unstable arm stops the experiment, without trimming.
- Reference and direct-to-original output/count checks before timing and serving
  checks after timing; reference hidden deviations remain explicitly recorded.
- All-position logits and sampled layer states are checked; hidden comparisons
  against original IREE must also pass the unchanged tolerance.
- Raw samples, hashes, checks, warmups and drift metrics retained.
- No assumed winner or minimum expected speedup. No new tuning search.

Compilation and loading can take several minutes and are outside timing.
If a phase fails, preserve the printed output path and bundle. A run can resume
with the same command plus `--resume /the/printed/output/path`.
Do not claim a performance result from failed or incomplete runs. Audit newly
observed hidden failures and routing differences before accepting a conclusion.

Upload the printed `dynamic_full_model_comparison_bundle.zip` after execution.

## Local validation and limits

The new split shell and segment helpers compiled for CUDA sm_80 and CPU on a
small two-layer model. CPU execution of the complete split path, including a small dynamically shaped
IREE expert kernel and exact-row assembly, matched reference logits, hidden
states and routing counts. The small dynamic expert also compiled for CUDA. Archive-backed shell-only
parameter materialization and export passed. The GPU dynamic expert itself
reuses its previously validated hash. The real 16-layer build, the complete
all-IREE GPU path, numerical agreement and A100 performance remain untested
until this script runs in Colab. The check is not an FP64 numerical diagnosis.
