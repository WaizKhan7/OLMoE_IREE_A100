module @bridge_prepared_e64 {
  func.func @forward(%x: tensor<64x47x2048xf32>, %gate_up: tensor<64x2048x2048xf32>, %down: tensor<64x1024x2048xf32>) -> tensor<64x47x2048xf32> {
    %zero = arith.constant 0.0 : f32
    %one = arith.constant 1.0 : f32
    %projected_empty = tensor.empty() : tensor<64x47x2048xf32>
    %projected_init = linalg.fill ins(%zero : f32) outs(%projected_empty : tensor<64x47x2048xf32>) -> tensor<64x47x2048xf32>
    %projected = linalg.batch_matmul ins(%x, %gate_up : tensor<64x47x2048xf32>, tensor<64x2048x2048xf32>) outs(%projected_init : tensor<64x47x2048xf32>) -> tensor<64x47x2048xf32>
    %gate = tensor.extract_slice %projected[0, 0, 0] [64, 47, 1024] [1, 1, 1] : tensor<64x47x2048xf32> to tensor<64x47x1024xf32>
    %up = tensor.extract_slice %projected[0, 0, 1024] [64, 47, 1024] [1, 1, 1] : tensor<64x47x2048xf32> to tensor<64x47x1024xf32>
    %activated_empty = tensor.empty() : tensor<64x47x1024xf32>
    %activated = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%gate, %up : tensor<64x47x1024xf32>, tensor<64x47x1024xf32>) outs(%activated_empty : tensor<64x47x1024xf32>) {
      ^bb0(%g: f32, %u: f32, %out: f32):
        %neg = arith.negf %g : f32
        %exp = math.exp %neg : f32
        %denom = arith.addf %one, %exp : f32
        %silu = arith.divf %g, %denom : f32
        %value = arith.mulf %silu, %u : f32
        linalg.yield %value : f32
    } -> tensor<64x47x1024xf32>
    %output_empty = tensor.empty() : tensor<64x47x2048xf32>
    %output_init = linalg.fill ins(%zero : f32) outs(%output_empty : tensor<64x47x2048xf32>) -> tensor<64x47x2048xf32>
    %output = linalg.batch_matmul ins(%activated, %down : tensor<64x47x1024xf32>, tensor<64x1024x2048xf32>) outs(%output_init : tensor<64x47x2048xf32>) -> tensor<64x47x2048xf32>
    return %output : tensor<64x47x2048xf32>
  }
}
